let questions = document.querySelectorAll(".question");
let results = document.querySelector(".results");
results.classList.add("hidden");
questions.forEach((question) => {
  question.classList.add("hidden");
});
questions[0].classList.remove("hidden");
let currentQuestion = 0;
document.querySelector("#next").addEventListener("click", nextQuestion);


function nextQuestion() {
  if (currentQuestion < questions.length - 1) {
    questions[currentQuestion].classList.toggle("hidden");
    currentQuestion++;
    questions[currentQuestion].classList.toggle("hidden");
  } else {

    let points = 0;
    let answers = document.querySelectorAll("[type='radio']:checked");
    answers.forEach((answer) => {
      points += parseInt(answer.value);
    });
    results.classList.toggle("hidden");
    if (points === 5) {
      document.querySelector(".result-headline").innerHTML = "Grattis!";
      document.querySelector(".result-body").innerHTML = "Du fick alla rätt!";
    }
    if (points === 4) {
      document.querySelector(".result-headline").innerHTML = "Grattis!";
      document.querySelector(".result-body").innerHTML = "Du fick 4/5 rätt!";
    }
    if (points === 3) {
      document.querySelector(".result-headline").innerHTML = "Grattis!";
      document.querySelector(".result-body").innerHTML = "Du fick 3/5 rätt!";
    }
    if (points === 2) {
      document.querySelector(".result-headline").innerHTML = "Grattis!";
      document.querySelector(".result-body").innerHTML = "Du fick 2/5 rätt!";
    }
    if (points === 1) {
      document.querySelector(".result-headline").innerHTML = "Grattis!";
      document.querySelector(".result-body").innerHTML = "Du fick 1/5 rätt!";
    }
    if (points === 0) {
      document.querySelector(".result-headline").innerHTML = "Grattis!";
      document.querySelector(".result-body").innerHTML = "Du fick alla fel!";
    }
  }
}
